<?php 
    session_start();

if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: index.php");
}
?>

<!doctype html>
<html>
    
<head>
    <title>Monkehh's DM Tools</title>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
     <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
function URL_add_parameter(url, param, value)
    {
    var hash       = {};
    var parser     = document.createElement('a');

    parser.href    = url;

    var parameters = parser.search.split(/\?|&/);

    for(var i=0; i < parameters.length; i++) {
        if(!parameters[i])
            continue;

        var ary      = parameters[i].split('=');
        hash[ary[0]] = ary[1];
    }

    hash[param] = value;

    var list = [];  
    Object.keys(hash).forEach(function (key) {
        list.push(key + '=' + hash[key]);
    });

    parser.search = '?' + list.join('&');
//    return parser.href;
    location.href = parser.search;
}    
</script>     

<link href="dmtools.css" rel="stylesheet" type="text/css">
    
    </head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">DM Tools</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Campaigns
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycampaigns.php">My Campaigns</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Characters
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycharacters.php">My Characters</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Retainers
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="myretainers.php">My Retainers</a>
          <a class="dropdown-item" href="quickretainercreator.php">Quick Retainer Creator</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
    <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
    </li>
        <?php if (!isset($_SESSION['username'])) : ?>
    <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
        <?php else: ?>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="login.php" style="color:blue; font-weight:bold;"><?php echo $_SESSION['username']; ?></a>
    </li>
    <li class="nav-item">
        <p><a class="nav-link" href="index.php?logout='1'" style="color: red;">Logout</a></p>
    </li>
        <?php endif ?>
    </ul>
<!--
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" href="login.php">Login</button>
    </form>
-->
  </div>

</nav> 
<hr>
<?php 
        include "db_connect.php";
        $userid = $_SESSION['user_id'];
        $retainer_id = $_GET['id'];
        
        $sql = "SELECT * FROM `user-retainers` WHERE `User-Retainer-ID` LIKE $retainer_id";    
        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();

        $retainer_user_id = $row['User'];
            
        if ($retainer_user_id=$userid): {
            
        $retainername = $row['Retainer-Name'];
        $retainerlevel = $row['Retainer-Level'];
        $retainertypeid = $row['Retainer-Type'];
        $assoc_character = $row['Assoc-Character'];
        $primarycolor = $row['primary-colour'];
        $secondarycolor = $row['secondary-colour'];
        $fontcolor = $row['profile-font-toggle']; ?>    

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a href="myretainers.php">My Retainers</a></li>
    <li class="breadcrumb-item"><a>Edit Retainer: <?php echo $retainername; ?></a></li>  
  </ol>
</nav>
    
<div class=container-flex style="padding-left:1em;">
    <div class="row">
        <div class="col-md-4">

<form method="post" enctype="multipart/form-data" action="/edit_retainer.php" class="form-horizontal">
<fieldset>

    <?php        
            
        $sql = "SELECT * FROM `characters` WHERE `character_id` LIKE $assoc_character";
        $result2 = $mysqli->query($sql);
        $row2 = $result2->fetch_assoc();
        $assoc_character = $row2['Character Name'];
    
        $sql ="SELECT RetainerName FROM retainer WHERE RetainerID LIKE $retainertypeid";
        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();
        $retainertype = $row['RetainerName'];
            
        $stmt = $mysqli->prepare("SELECT RetainerName FROM retainer");
        $stmt->execute();
        $retainers = [];
        $userid = $_SESSION['user_id'];
    
        foreach ($stmt->get_result() as $row) {
            $retainers[] = $row['RetainerName'];
        }

            

        $stmt = $mysqli->prepare("SELECT `Character Name` FROM `characters` WHERE `User` LIKE $userid");
        $stmt->execute();
        $characters = [];
            
        foreach ($stmt->get_result() as $row2) {
            $characters[] = $row2['Character Name'];
        } 
    ?>
<!-- Form Name -->
<legend>Edit Retainer</legend>

    

<!-- Text input-->
<div class="form-group">
  <label class="col-md-5 control-label" for="name">Retainer Name</label>  
  <div class="col-md-6">
  <input id="name" name="name" type="text" value=<?php echo '"'.$retainername.'"' ?> class="form-control input-md" required="">  
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="type">Retainer Type</label>
  <div class="col-md-5">
<select name="type" id="array" class="form-control" value="<?php echo '"'.$retainertype.'"' ?>">  
    <?php
    
          
        sort($retainers, SORT_STRING);
        foreach ($retainers as $value)  {
            if ($value != $retainertype): {
            echo '<option value="'.$value.'">'.$value.'</option>'; 
            }
            elseif ($value = $retainertype): {
            echo '<option value="'.$value.'"selected>'.$value.'</option>';
            }
            endif;
            
        }
    
    ?> 
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="level">Level</label>
  <div class="col-md-3">
    <select id="level" name="level" class="form-control">
        
    <?php
    for ($i = 1; $i < 8; $i++) {
    
        if ($i != $retainerlevel):{
        echo "<option>".$i."</option>";
        
//        if ($i=$retainerlevel):{
//        echo "<option selected>".$i."</option>";
//        }
//        elseif ($i!=$retainerlevel): {
//        echo "<option>".$i."</option>";    
//        }
//        endif;
//        '<option value="'.$i.'">'.$i.'</option>';
    }
        else: {
           echo "<option selected>".$i."</option>"; 
        }
        endif;
    }
            ?>
    </select>
  </div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="assoc-character">Character</label>
  <div class="col-md-6">
<select name="assoc-character" id="array" class="form-control">
    <?php
              
        sort($retainers, SORT_STRING);
        foreach ($characters as $value)  {
            
            if ($value!=$assoc_character): {
                echo '<option value="'.$value.'">'.$value.'</option>';   
            }
            elseif ($value=$assoc_character): {
            echo '<option value="'.$value.'"selected>'.$value.'</option>';   
            
            }
            
            endif;           
        }
            
    
    ?>      
    </select>
    <a style="font-style: italic;">Who does this retainer serve?</a>
  </div>
</div>

<div class="form-group">
<label class="col-md-4 control-label" for="image">Portrait</label>
<div class="col-md-6">
<input type="hidden" name="size" value="1000000">
<div>  
  <input type="file" id="image" name="image" class="input-file">
</div>    
</div>
</div> 
    
<div class="form-group">

<label class="col-md-4 control-label" for="font">Colors</label>  
  <div class="col-md-2">
  <div class="checkbox">
      <input type="color" name="font-color" id="font-color" value=<?php echo '"'. $fontcolor . '"' ?>>
    </div>
     Portrait Font
  </div>
</div>
<div class="form-group">
  <div class="col-md-2">
  <div class="checkbox">
      <input type="color" name="primary-color" id="primary-color" value=<?php echo '"'. $primarycolor . '"' ?>>
    </div>
     Primary Colour
  </div>
  <div class="col-md-2">
  <div class="checkbox">
      <input type="color" name="secondary-color" id="secondary-color" value=<?php echo '"'. $secondarycolor . '"' ?>>
    </div>
     Secondary Colour
  </div>
</div>
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="createretainer"></label>
  <div class="col-md-4">
    <button id="createretainer" name="id" class="btn btn-primary" value= <?php
            echo "$retainer_id"; ?>
            
            >Edit Retainer</button>
  </div>
</div>

</fieldset>
</form>      
        
        <?php
            
                    }
         else: {
             
             echo "Invalid Retainer ID provided, please try again.";
         }
        endif;
?>
        </div>
        <div class="col-md-4 col-xs-12" style="padding-top: 10px;">
        <?php include "retainercardgenerator.php"; ?>
        </div>
    </div>
</div>
    </body>
</html>