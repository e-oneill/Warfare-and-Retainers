<?php if (count($changes) > 0) : ?>

<div class="row">
    <?php foreach ($changes as $change) : ?>
     <p><?php echo $change ?></p>
    <?php endforeach ?>
</div>

<?php endif ?>