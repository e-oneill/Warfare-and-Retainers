<?php 
    session_start();

if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: index.php");
}
?>

<!doctype html>
<html>
    
<head>
    <title>Monkehh's DM Tools</title>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
     <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<link href="dmtools.css" rel="stylesheet" type="text/css">
    </head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">DM Tools</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Campaigns
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycampaigns.php">My Campaigns</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Characters
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycharacters.php">My Characters</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Retainers
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="myretainers.php">My Retainers</a>
            <a class="dropdown-item" href="create_retainer.php">Create Retainer</a>
          <a class="dropdown-item" href="quickretainercreator.php">Quick Retainer Creator</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
    <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
    </li>
        <?php if (!isset($_SESSION['username'])) : ?>
    <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
        <?php else: ?>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="login.php" style="color:blue; font-weight:bold;"><?php echo $_SESSION['username']; ?></a>
    </li>
    <li class="nav-item">
        <p><a class="nav-link" href="index.php?logout='1'" style="color: red;">Logout</a></p>
    </li>
        <?php endif ?>
    </ul>
<!--
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" href="login.php">Login</button>
    </form>
-->
  </div>

</nav> 
    
<!--
<div class="jumbotron">
  <h1 class="display-4">Tools for Dungeon Masters!</h1>
  <hr class="my-4">
<p class="lead">Helping you run the game.</p>
  <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
  </p>
</div>
-->
<section class="details-card">
<!--    <div class="container">-->
        <div class="row">
        <div class="col-md-4" id="card1">
                <div class="card-content">
<!--
                    <div class="card-img">
                          <a href="quickretainercreator.php"><img src="images/retainercardesigner.png" alt="retainer card designer"></a>
                    </div>
-->
                    <div class="card-desc">
                        <a href="mycampaigns.php"><h3>Campaigns</h3></a>
                        <p>Tools for tracking and organising your campaign and the items within them!</p>
<!--                            <a href="#" class="btn-card">Read</a>   -->
                    </div>
                </div>
            </div>
            <div class="col-md-4" id="card2">
                <div class="card-content">
<!--
                    <div class="card-img">
                          <a href="quickretainercreator.php"><img src="images/retainercardesigner.png" alt="retainer card designer"></a>
                    </div>
-->
                    <div class="card-desc">
                        <a href="mycharacters.php"><h3>Characters</h3></a>
                        <p>An adventure can't happen without adventurers!</p>
<!--                            <a href="#" class="btn-card">Read</a>   -->
                    </div>
                </div>
            </div>
            <div class="col-md-4" id="card3">
                <div class="card-content">
<!--
                    <div class="card-img">
                          <a href="quickretainercreator.php"><img src="images/retainercardesigner.png" alt="retainer card designer"></a>
                    </div>
-->
                    <div class="card-desc">
                        <a href="myretainers.php"><h3>Retainers</h3></a>
                        <p>It's dangerous out there, so don't go it alone. Here, you'll find tools for the people who tag along.</p>
<!--                            <a href="#" class="btn-card">Read</a>   -->
                    </div>
                </div>
            </div>
            <div class="col-md-4" id="card3">
                <div class="card-content">
<!--
                    <div class="card-img">
                          <a href="quickretainercreator.php"><img src="images/retainercardesigner.png" alt="retainer card designer"></a>
                    </div>
-->
                    <div class="card-desc">
                        <a href="myretainers.php"><h3>Armies</h3></a>
                        <p>Track and manage the soldiers who flock to your banner.</p>
<!--                            <a href="#" class="btn-card">Read</a>   -->
                    </div>
                </div>
            </div>
            <div class="col-md-4">
<!--
                <div class="card-content">
                    <div class="card-img">
                        <img src="https://placeimg.com/380/230/animals" alt="">
                    </div>
                    <div class="card-desc">
                        <h3>Campaign Setting</h3>
                        <p>Explore the world of my custom 5e campaign setting!</p>
                    </div>
                </div>
-->
            </div>
            <div class="col-md-4">
                <!--<div class="card-content">
                    <div class="card-img">
                        <img src="https://placeimg.com/380/230/tech" alt="">
                    </div>
                    <div class="card-desc">
                        <h3>Captain Setting</h3>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam, voluptatum! Dolor quo, perspiciatis
                            voluptas totam</p>
                            <a href="#" class="btn-card">Read</a>   
                    </div>
                </div>-->
            </div>
        </div>
<!--    </div>-->
</section> 
    </body>
</html>