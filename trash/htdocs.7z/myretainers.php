<?php 
    session_start();

if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: index.php");
}
?>

<!doctype html>
<html>
    
<head>
    <title>Monkehh's DM Tools</title>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
     <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
function URL_add_parameter(url, param, value)
    {
    var hash       = {};
    var parser     = document.createElement('a');

    parser.href    = url;

    var parameters = parser.search.split(/\?|&/);

    for(var i=0; i < parameters.length; i++) {
        if(!parameters[i])
            continue;

        var ary      = parameters[i].split('=');
        hash[ary[0]] = ary[1];
    }

    hash[param] = value;

    var list = [];  
    Object.keys(hash).forEach(function (key) {
        list.push(key + '=' + hash[key]);
    });

    parser.search = '?' + list.join('&');
//    return parser.href;
    location.href = parser.search;
}    
</script>     

<link href="dmtools.css" rel="stylesheet" type="text/css">
    
    </head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">DM Tools</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Campaigns
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycampaigns.php">My Campaigns</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Characters
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="mycharacters.php">My Characters</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Retainers
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="myretainers.php">My Retainers</a>
            <a class="dropdown-item" href="create_retainer.php">Create Retainer</a>
          <a class="dropdown-item" href="quickretainercreator.php">Quick Retainer Creator</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
    <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
    </li>
        <?php if (!isset($_SESSION['username'])) : ?>
    <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
        <?php else: ?>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="login.php" style="color:blue; font-weight:bold;"><?php echo $_SESSION['username']; ?></a>
    </li>
    <li class="nav-item">
        <p><a class="nav-link" href="index.php?logout='1'" style="color: red;">Logout</a></p>
    </li>
        <?php endif ?>
    </ul>
<!--
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" href="login.php">Login</button>
    </form>
-->
  </div>

</nav> 
<hr>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a>My Retainers</a></li>
  </ol>
</nav>
<div class="container-flex" style="padding-left: 10px;">
<div class="row">
<div class="col-md-12">
<h1>My Retainers</h1>
</div>
</div>
<div class="row">
<div class="col-md-12">
<?php
$changes = array();
    
        include "changes.php";
        include "db_connect.php";
        if (!empty($_SESSION['user_id'])) { ?>
<!-- href="myretainers.php?add_retainer=yes"   -->
<a href="create_retainer.php" class="btn btn-primary btn-xs pull-right col-3"><b>+</b> Add new retainer</a>

<?php        
        $userid = $_SESSION['user_id'];
        $sql = "SELECT * FROM `user-retainers` WHERE `User` LIKE $userid";
        $result = $mysqli->query($sql);
        $character = "";
        
        
        if ($result->num_rows > 0) { 
    
?>
<!--
</div>    
</div>
<div class="row">
-->
<div id="retainers-table" class="">


            
    <table class="table table-striped custab col-lg-10 col-md-11 col-xs-12">
    <thead>

        <tr>
            <th style="width: 10%;">Name</th>
            <th style="width: 10%;">Type</th>
            <th style="width: 10%;">PC</th>
            <th style="width: 20%;"></th>
        </tr>
            </thead>
           
    <?php
            // output data of each row
            while($row = $result->fetch_assoc()) {
        
                
            $retainername = $row['Retainer-Name'];    
            $typeid = $row['Retainer-Type'];
            $retainer_id = $row['User-Retainer-ID'];
            $assoc_character = $row['Assoc-Character'];
            
            $sql = "SELECT * FROM `characters` WHERE `character_id` LIKE $assoc_character";
            $result2 = $mysqli->query($sql);
            $row2 = $result2->fetch_assoc();
            $assoc_character = $row2['Character Name'];
               
            $sql = "Select * FROM `retainer` WHERE `RetainerID` LIKE $typeid";
            $result1 = $mysqli->query($sql);
            $row1 = $result1->fetch_assoc();
            $type = $row1['RetainerName']; ?>
    
    <tr>
                <td><?php echo $retainername; ?></td>
                <td><?php echo $type; ?></td>
                <td><?php echo $assoc_character; ?></td>
                <td class="text-center">
                <a class="btn btn-success btn-xs cstbtn-retainer-table"
                    <?php 
                
                echo 'href="retainer.php?id='.$retainer_id.'"'; 
                    
                    
                    ?>                                         
                                           
                                           ><span class="glyphicon glyphicon-edit"></span>View</a> 
                    
                    <a class="btn btn-info btn-xs cstbtn-retainer-table"
                <?php echo 'href="edit_retainer_form.php?id='.$retainer_id.'"';
                ?>
                    
                   
                    
                    ><span class="glyphicon glyphicon-remove "></span>Edit</a>
        <a class="btn btn-danger btn-xs cstbtn-retainer-table" href=""><span class="glyphicon glyphicon-remove"></span>Delete</a>
        </td>
    </tr> 
    
<!--
             echo 
                 '<a href="myretainers.php?id='.$retainer_id.'&name=' .
                 $row['Retainer-Name'] . "&type=" . $type . "&retainerlevel=" . $row['Retainer-Level'] . '">' . $row['Retainer-Name'] . "</a></br>";   
-->
            
    
    <?php
    } 
        ?>

    </table>
</div>
    <?php
        }
         ?>

    
 

    
        
        <?php 
        if (isset($_GET["id"]) And !isset($_GET['edit_retainer'])) : {
            
        ?>
        <div class="col-md-4 col-xs-12" style="padding-top: 10px;">
            <?php
            $id = $_GET["id"];
            
            ?>
            
            
            <?php
            
            $popoutlink = "";
            echo $popoutlink;
            include "retainercardgenerator.php";
        
        ?>
    <script>
    function createpopout {
    var cardheight = $("#retainer-front").height();
        
    newwindow = window.open(`'retainer_pop_out.php?id=41', 'mywindow', 'width=460', 'height=${cardheight}'`);
        
    return newwindow;
    }
    </script>
  <button class="btn btn-primary btn-xs pull-right" onclick="window.open(createpopout())" >Popout</button>              
        </div>
        <?php
            }
        endif;
        if (isset($_GET['add_retainer'])): {
            ?>

    <div class="col-md-4 col-xs-12" style="padding-top: 10px;">        
    <?php
        
           include "retainer_creation_form.php";
     ?>
    </div>
    <?php
            }

?>
 


<!--
<div class="col-md-10">
    <div class="container">
        <div class="row">
<div class="col-md-2"></div>
        <div class="npc-top-block">
            <div class="npc-name">
            Test 1
            </div>
            <div class="npc-type">
            Test Type
            </div>
            <div class="npc-level">
            Test Level
            </div>
        </div> 
        </div>
        <div class="row">
        <div class ="npc-ability-block">
        Test
        </div>
        </div>
    </div>
</div>
-->
        
        <?php
        
        
        elseif (isset($_GET['edit_retainer'])): {
            ?>
        <div class="col-md-4 col-xs-12" style="padding-left: 20px; padding-top: 10px;"> 
           
        <?php
        echo "<h1>Edit Retainer</h1>";
            include "edit_retainer_form.php";
            
        ?>
        
        </div>
        <div class="col-md-4 col-xs-12" style="padding-top: 10px;">
        <?php include "retainercardgenerator.php"; ?>
        </div>
        <?php
        
        }
        
        endif;
            ?>
        
    <?php
         }
        else {

    
    echo "<h5>You must be logged in to view your saved retainers.</h5>";
    }
        
   
?>
    
    
   
    
    </div>
    </div>
    </div>

    </body>
</html>