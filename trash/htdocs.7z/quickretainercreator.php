<?php 
    session_start();

if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: index.php");
}
?>

<!doctype html>
<html>
    
<head>
    <title>Monkehh's DM Tools</title>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
     <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
 document.getElementById("image-button").innerHTML = "Upload New Image";
}    
</script>
<link href="dmtools.css" rel="stylesheet" type="text/css">
    </head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">DM Tools</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Retainer Card Creator</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Retainers
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="myretainers.php">My Retainers</a>
          <a class="dropdown-item" href="quickretainercreator.php">Quick Retainer Creator</a>
<!--
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
-->
        </div>
      </li>
    <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
    </li>
        <?php if (!isset($_SESSION['username'])) : ?>
    <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
        <?php else: ?>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="login.php" style="color:blue; font-weight:bold;"><?php echo $_SESSION['username']; ?></a>
    </li>
    <li class="nav-item">
        <p><a class="nav-link" href="index.php?logout='1'" style="color: red;">Logout</a></p>
    </li>
        <?php endif ?>
    </ul>
<!--
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" href="login.php">Login</button>
    </form>
-->
  </div>

</nav>   
    
<div class="col-md-2"></div>
<div class="col-md-10">
    <h1>Retainer Tools</h1>
<!--    <p>This is testing the PHP to call from a MySQL database.</p>-->
    

<?php

    include "db_connect.php";

//if there are any values in a table, display them one at a time
    
//    include "search_all_abi.php";

?>
<!-- <form action="/search_keyword_retainer.php">
  <label for="fname">Enter Retainer to search for:</label><br>
  <input type="text" name="keyword"><br>

  <input type="submit" value="Submit">
</form> -->
    
    
<hr>
</div>
    
<?php
    
        $stmt = $mysqli->prepare("SELECT RetainerName FROM retainer");
        $stmt->execute();
        $retainers = [];
    
        foreach ($stmt->get_result() as $row) {
            $retainers[] = $row['RetainerName'];
        }    
    ?>
    
<!--
<select name="keyword" id="array">
    <?php
        sort($retainers, SORT_STRING);
        foreach ($retainers as $value)  {
            printf('<option>%s</option>option>',$value);
            
        }
    
    ?>
</select>
<div class="control-group">
  <label class="control-label" for="Submit"></label>
  <div class="controls">
    <button id="Submit" name="Submit" class="btn btn-info">Search</button>
  </div>
</div>
-->
<div class="col-md-4">
        <form action="/search_keyword_retainer.php" class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Quick Retainer Creator</legend>
    
<!-- Text input-->
<div class="form-group">
  <label class="control-label" for="name">Retainer Name</label>  
  <div class="">
  <input id="name" name="name" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Search input-->
<div class="form-group">
  <label class="control-label" for="keyword">Select Retainer Type</label>
  <div class="controls">
<select name="keyword" id="array" class="form-control">
    <?php
        sort($retainers, SORT_STRING);
        foreach ($retainers as $value)  {
            printf('<option>%s</option>option>',$value);
            
        }
    
    ?>
</select>
  </div>
</div>
    
<!-- Select Basic -->
<div class="form-group">
  <label class="control-label" for="retainerlevel">Retainer Level</label>
  <div class="">
    <select id="retainerlevel" name="retainerlevel" class="form-control">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
    </select>
  </div>
</div>

<div class="form-group">


<div id="wrapper" class="col">
<img id="output_image" style="width:100%;"/>
  <label class="form-button" id="image-button" for="image" style="width:100%;padding-top:0.5rem; margin-left: 0;" onclick="preview_image(event)"> + Character Image</label>
 <input id="image" type="file" accept="image/*" name="image" onchange="preview_image(event)">
 
</div>
</div>
    
<!-- Button -->
<div class="control-group">
  <label class="control-label" for="Submit"></label>
  <div class="controls">
    <button id="Submit" name="Submit" class="btn btn-info">Create</button>
  </div>
</div>

</fieldset>
</form>
    </div>
<!--     <form action="/add_retainer.php">
  <label for="RetainerName">Add Retainer Here:</label><br>
        <input type="text" name="RetainerName"><br>
    <label for="RetainerBaseClass">Base Class:</label><br>
        <input type="text" name="RetainerBaseClass"><br>
  <input type="submit" value="Submit">
</form> -->
    
    <!--
    <form action="/add_retainer.php" class="form-horizontal">
<fieldset>
    
<!-- Form Name 
<legend>Create New Retainer</legend>

<!-- Text input
<div class="control-group">
  <label class="control-label" for="RetainerName">Retainer Name</label>
  <div class="controls">
    <input id="RetainerName" name="RetainerName" type="text" placeholder="e.g. Super Awesome Man 3,000" class="input-xlarge" required="">
    <p class="help-block">Add a name for your new Retainer</p>
  </div>
</div>

<!-- Text input
<div class="control-group">
  <label class="control-label" for="RetainerBaseClass">Retainer Base Class</label>
  <div class="controls">
    <input id="RetainerBaseClass" name="RetainerBaseClass" type="text" placeholder="e.g. Rogue" class="input-xlarge" required="">
    <p class="help-block">Which class is your retainer based on?</p>
  </div>
</div>

<!-- Button 
<div class="control-group">
  <label class="control-label" for="submit"></label>
  <div class="controls">
    <button id="submit" name="submit" class="btn btn-primary">Create Retainer</button>
  </div>
</div>

</fieldset>
</form>
-->  


<!--<div class="col-md-10">
    <div class="container">
        <div class="row">
<div class="col-md-2"></div>
        <div class="npc-top-block">
            <div class="npc-name">
            Test 1
            </div>
            <div class="npc-type">
            Test Type
            </div>
            <div class="npc-level">
            Test Level
            </div>
        </div> 
        </div>
        <div class="row">
        <div class ="npc-ability-block">
        Test
        </div>
        </div>
    </div>
</div>-->
<?php
//    include "search_keyword.php";
    
    
$mysqli->close();    
    
    
?>

    </body>
</html>